import type { Options } from './types.js';
export default function inspectString(string: string, options: Options): string;
//# sourceMappingURL=string.d.ts.map