export default function inspectSymbol(value: Symbol): string;
//# sourceMappingURL=symbol.d.ts.map