import type { Options } from './types.js';
export default function inspectBigInt(number: bigint, options: Options): string;
//# sourceMappingURL=bigint.d.ts.map