import type { Options } from './types.js';
export default function inspectMap(map: Map<unknown, unknown>, options: Options): string;
//# sourceMappingURL=map.d.ts.map