import type { Options } from './types.js';
export default function inspectNumber(number: number, options: Options): string;
//# sourceMappingURL=number.d.ts.map