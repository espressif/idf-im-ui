import type { Options } from './types.js';
export default function inspectClass(value: {
    new (...args: any[]): unknown;
}, options: Options): string;
//# sourceMappingURL=class.d.ts.map