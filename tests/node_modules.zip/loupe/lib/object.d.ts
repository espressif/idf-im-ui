import type { Options } from './types.js';
export default function inspectObject(object: object, options: Options): string;
//# sourceMappingURL=object.d.ts.map