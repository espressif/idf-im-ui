import type { Options } from './types.js';
type ToStringable = Function & {
    [Symbol.toStringTag]: string;
};
export default function inspectFunction(func: ToStringable, options: Options): string;
export {};
//# sourceMappingURL=function.d.ts.map