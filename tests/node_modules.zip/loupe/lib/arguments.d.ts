import type { Options } from './types.js';
export default function inspectArguments(args: IArguments, options: Options): string;
//# sourceMappingURL=arguments.d.ts.map